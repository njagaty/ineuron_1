def fn31():
    print("This is function-1 inside Mod3")
    
