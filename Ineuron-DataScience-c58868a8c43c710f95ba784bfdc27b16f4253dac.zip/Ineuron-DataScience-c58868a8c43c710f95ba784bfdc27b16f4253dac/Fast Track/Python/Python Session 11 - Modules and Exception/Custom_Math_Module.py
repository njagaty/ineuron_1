def addition(a, b):
    '''
    Function to return the addition of 2 numbers
    '''
    return a+b

def mul(a, b):
    return a*b

def power(a, b):
    return a**b