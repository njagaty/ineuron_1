data = {
    "name" : "Chandan",
    "courses" : ['ML' 'AI', 'Stats', 'Math', 'CV'],
    "msg" : "This is my custom class"
}

def get_course():
    'Function to return all the courses'
    return data['courses']

def msg():
    return data['msg']