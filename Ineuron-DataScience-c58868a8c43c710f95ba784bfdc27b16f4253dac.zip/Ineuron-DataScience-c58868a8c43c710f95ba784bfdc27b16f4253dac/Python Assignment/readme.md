Contain Python assignments
