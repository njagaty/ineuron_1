## Ineuron-DataScience

1. Python
2. Python Assignment
3. Databases
4. Flask
5. Projects
