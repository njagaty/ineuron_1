class ArchiveError(Exception):
    pass
