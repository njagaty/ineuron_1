Fast Track Mode Codes
