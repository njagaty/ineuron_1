def fn1():
    print("Inside main directory in test1_Mod")